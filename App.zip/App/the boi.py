#password protection
import os
#import Password
#todo app code
#tools import
import sqlite3
#database connections and mouse setup
i_pee = sqlite3.connect("to-do.db")
seed = i_pee.cursor()
def createtable():
#creates table and primary keys
  i_pee.execute
  """CREATE TABLE "tasks" ( "task_ID" INTEGER UNIQUE, 
    "task" TEXT, 
    "complete" BLOB, 
    PRIMARY KEY("task_ID" AUTOINCREMENT) );"""
  i_pee.commit()
createtable()

def search():
  #search database
  i_pee.execute
  U_I_task = input("Task: ")
  U_I_complete = input("Complete?: ")
  query = ("""INSERT INTO task (task_name, complete) VALUES (?,?)""",[U_I_task], [U_I_complete])

def insert_task():
      #user input
      U_I_task = input("Task: ")
      U_I_complete = input("Complete?: ")
    
      #insert tasks
      seed.executemany
      ("""INSERT INTO tasks (task_name, complete) VALUES (?,?)""",[U_I_task], [U_I_complete])
      i_pee.commit()
      print ("Data entered successfully. :)")
      i_pee.close()
      if (i_pee):
          i_pee.close()
          print("\nThe SQLite connection is closed.")

def update():
      #This will allow the user to update a selected task with the task id
      i_pee.commit
      query = """(UPDATE task SET task_name = ?, complete = ?, WHERE task_id = ?);"""
      try:
        seed.execute(query,[task_id], [task_name], [complete])
      except:
          print("Invalid input")
      else:
          i_pee.commit()
          print("task with task id {task_id} has been updated")
          i_pee.close()
          print("\nThe SQLite connection is closed.")          

def delete():
      i_pee.commit
      search()
      TaskID = input("Enter the task id of the task you wish to permanently delete: ")
      query = """(DELETE FROM task WHERE task_id = ?);"""
      try:
          seed.execute(query, {task_id})
      except:
          print("There was an error deleting the task")
      else:
          i_pee.commit()
          print("Car with task id {task_id} has been deleted")
          i_pee.close()
          print("\nThe SQLite connection is closed.")          
          
def menu():
  #selection screen
  print("Below are the number to help you enter options and come back to the menu.")
  print("[1] insert task")
  print("[2] view tasks (pip install pandas in terminal/command prompt if not working)")
  print("[3] update task")
  print("[4] delete task")
  print("[5] back to menu")
  print("[0] exit")
menu()
op = int(input("enter option: "))

while op !=0:
  if op == 1:
    insert_task()
    input("To go back to menu enter to go back to menu: ")

  elif op == 2:
    search()
    input("To go back to menu enter to go back to menu: ")

  elif op == 3:
    update()
    input("To go back to menu enter to go back to menu: ")

  elif op == 4:
      delete()
      input("To go back to menu enter to go back to menu: ")
    
  elif op == 5:

    menu()

  elif op == 0: 
    exit
  else:
    print("SORRY! You need to chose a valid option from 0 - 4")
  
  print()
  menu()
  op = int(input("enter option: "))

print("Thanks for using your todo list today, have a nice day :)")

def SQL_Secure():
#Securing the db
    sec = "task_id'; DROP TABLE task;--"
    sec_l2 = (sec)
    seed.execute("SELECT * from task WHERE sec=(?)" , sec_l2)
SQL_Secure()