#Tools import 
from getpass import getpass
#password protection
user = input("*Enter username: ")
user_pass = getpass("*Enter password: ")
username = "42069"
password = "password"
#verifies user
while not(username==user and password==user_pass):
  print("Try again, incorrect credentials :( ")
  user = input("*Enter username: ")
  user_pass = getpass("*Enter password: ")
else:
  True 
  print("Correct credentials, Welcome!")
  exit